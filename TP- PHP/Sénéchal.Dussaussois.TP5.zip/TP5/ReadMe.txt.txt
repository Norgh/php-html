---| Auteurs |---

Sénéchal Pierre
Dussaussois Victor


---| Nom du site |---

Covi'Drive


---| Slogan |---

Avec Covi'Drive, écrasez le covid!


---| Logo |---

Un logo réalisé par nos soins.
Logo composé de : 
- Une Fiat Multipla
- Un Covid
- 2 CIR1 anonymes (JCDLRSA & PM)


---| Description |---

*-* Un login utilisateur :
 -accès à la liste des produits
 -commande des produits
 -accéder à leur profil et modifer les informations personnelles
 -une page indiquant les créneaux horaires + réservation d'un créneau

*-* Un login fournisseur :
 -accès aux stocks
 -modification des stocks


#Pour résumer le site doit comprendre une base de donnée qui inclut:
 -une table contenant le nom et la quantité des produits
 -une table mémorisant les produits du panier de l'utilisateur
 -une table contenant les créneaux horaires et leur état Libre/Réservé


---| Instructions |---

Connectez-vous avec le login utilisateur ou fournisseur.
Découvrez le site et passez commande auprès de vos fournisseurs favoris!


---| Conseils |---

Un login ainsi qu'un mot de passe "client" et également "fournisseur" vont ont été préalablement crées par les créateurs de votre site préféré.

*-* Client : 
Login : Lucifer
Mot de passe : 1010011010

*-* Fournisseur : 
Login : Satan
Mot de passe : 666


---| IMPORTANT |---

Veuillez ouvrir le fichier connexion.php (ou accueil_client.php) pour commencer à naviguer sur note site!


---| Autres |---

Peur du covid? N'hésitez pas à consulter notre page dédiée "informations covid" disponible sur le site.

NB : STOCKS de PQ, Pâtes, Gel Hydroalcoolique et masques de protection ffp2 LIMITÉS, dépêchez-vous!


---| Sponsors |---

Vous aimez notre site et souhaitez nous soutenir?
Envoyez un don à https://don.fondationhopitaux.fr/

