<!DOCTYPE html>
<html lang="fr">
<head>
<meta charset="utf-8">
<link rel="stylesheet" href="covidrive.css">
<title>Covi'Drive</title>
</head>
<body>
	<div class="top">
		<h1 style="text-align:center;">Covi'Drive</h1>
		<img src="CoviDriveLogo.png" width="100" id="logoentete"/>
   		<div class="menu">
			<nav>
			<ul>
            	<li><a href="accueil_fournisseur.php"><i aria-hidden="true"></i> Stock</a></li>
				<li><a href="gerer_stock.php"><i aria-hidden="true"></i>Gérer stock</a></li>
            	<li><a href="creneaux_fournisseur.php"><i aria-hidden="true"></i>Créneaux</a></li>
				<li><a href="deconnexion.php"><i aria-hidden="true"></i>Se déconnecter</a></li>
			</nav>
		</div>
	</div>
	</br></br></br>
</body>
</html>