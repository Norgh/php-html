<!DOCTYPE html>
<html lang="fr">
<head>
<meta charset="utf-8">
<link rel="stylesheet" href="covidrive.css">
<title>Covi'Drive</title>
</head>
<body>
	<div class="top">
		<h1 style="text-align:center;">Covi'Drive</h1>
		<img src="CoviDriveLogo.png" width="100" id="logoentete"/>
   		<div class="menu">
			<nav>
			<ul>
       	   		<li><a href="accueil_client.php"><i aria-hidden="true"></i> Accueil</a></li>
				<li><a href="panier.php"><i aria-hidden="true"></i> Mon panier</a></li>
            	<li><a href="informations_personnelles.php"><i aria-hidden="true"></i> Mes informations</a></li>
				<li><a href="informations_covid.php"><i aria-hidden="true"></i> Infos Covid</a></li>
				<li><a href="deconnexion.php"><i aria-hidden="true"></i>Se déconnecter</a></li>
			</ul>
			</nav>
		</div>
	</div>
	</br></br></br>
</body>
</html>