<!DOCTYPE html>
<html lang="fr">
<head>
<meta charset="utf-8">
<link rel="stylesheet" href="covidrive.css">
<title>Covi'Drive</title>
</head>
<body>
    <div class="basdepage">
        <p class="foot"><img src="CoviDriveLogo.png" width="100"/>Avec Covi'Drive, écrasez le Covid</p>
    </div>
	
	<img src="coffindance.png" width="100" id="logobas"/>
	
</body>
</html>